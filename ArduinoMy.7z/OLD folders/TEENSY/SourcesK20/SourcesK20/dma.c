/*
 * dma.c
 *
 *  Created on: Oct 14, 2014
 *      Author: b52932
 */
#include "dma.h"
#include "MK20D7.h"

unsigned char g8bSource[10] = {0,1,2,3,4,5,6,7,8,9};
unsigned char g8bDestiny[10] = {1,0,0,0,0,0,0,0,0,0};


/*	init_DMA_1Trans
 * 
 * 	Initializes channel 0 DMA registers in order to perform 1 data transfer of 5 bytes
 * 	and sets Port C as DMA request source
 * 
 * */
void init_DMA_1Trans(void)
{
	// Enable clock for DMAMUX and DMA
	SIM->SCGC6 |= SIM_SCGC6_DMAMUX_MASK;
	SIM->SCGC7 |= SIM_SCGC7_DMA_MASK;
			
	// Enable Channel 0 and set Port C as DMA request source 
	DMAMUX->CHCFG[0] |= DMAMUX_CHCFG_ENBL_MASK | DMAMUX_CHCFG_SOURCE(51);


	// Enable request signal for channel 0 
	DMA0->ERQ = DMA_ERQ_ERQ0_MASK;
		
	// Set memory address for source and destination 
	DMA0->TCD[0].SADDR = (uint32_t)&g8bSource;
	DMA0->TCD[0].DADDR = (uint32_t)&g8bDestiny;

	// Set an offset for source and destination address
	DMA0->TCD[0].SOFF = 0x02; // Source address offset of 2 bits per transaction
	DMA0->TCD[0].DOFF = 0x01; // Destination address offset of 1 bit per transaction
		
	// Set source and destination data transfer size
	DMA0->TCD[0].ATTR = DMA_ATTR_SSIZE(0) | DMA_ATTR_DSIZE(0);
		
	// Number of bytes to be transfered in each service request of the channel
	DMA0->TCD[0].NBYTES_MLNO = 0x05;
		
	// Current major iteration count (a single iteration of 5 bytes)
	DMA0->TCD[0].CITER_ELINKNO = DMA_CITER_ELINKNO_CITER(1);
	DMA0->TCD[0].BITER_ELINKNO = DMA_BITER_ELINKNO_BITER(1);
	
	// Adjustment value used to restore the source and destiny address to the initial value
	DMA0->TCD[0].SLAST = -0x0A;		// Source address adjustment
	DMA0->TCD[0].DLAST_SGA = -0x05;	// Destination address adjustment
	
	// Setup control and status register
	DMA0->TCD[0].CSR = 0;
}


/*	init_DMA_1Elem
 * 
 * 	Initializes channel 0 DMA registers in order to perform 5 data transfers of 1 byte each
 * 	and sets Port C as DMA request source
 * 
 * */
void init_DMA_1Elem(void)
{	

	// Enable clock for DMAMUX and DMA
	SIM->SCGC6 |= SIM_SCGC6_DMAMUX_MASK;
	SIM->SCGC7 |= SIM_SCGC7_DMA_MASK;
		
	// Enable Channel 0 and set Port C as DMA request source 
	DMAMUX->CHCFG[0] |= DMAMUX_CHCFG_ENBL_MASK | DMAMUX_CHCFG_SOURCE(51);

	// Enable request signal for channel 0 
	DMA0->ERQ = DMA_ERQ_ERQ0_MASK;
	
	// Set memory address for source and destination 
	DMA0->TCD[0].SADDR = (uint32_t)&g8bSource;
	DMA0->TCD[0].DADDR = (uint32_t)&g8bDestiny;

	// Set an offset for source and destination address
	DMA0->TCD[0].SOFF = 0x02; // Source address offset of 2 bits per transaction
	DMA0->TCD[0].DOFF = 0x01; // Destination address offset of 1 bit per transaction
	
	// Set source and destination data transfer size
	DMA0->TCD[0].ATTR = DMA_ATTR_SSIZE(0) | DMA_ATTR_DSIZE(0);
	
	// Number of bytes to be transfered in each service request of the channel
	DMA0->TCD[0].NBYTES_MLNO = 0x01;
	
	// Current major iteration count (5 iteration of 1 byte each)
	DMA0->TCD[0].CITER_ELINKNO = DMA_CITER_ELINKNO_CITER(5);
	DMA0->TCD[0].BITER_ELINKNO = DMA_BITER_ELINKNO_BITER(5);
	
	// Adjustment value used to restore the source and destiny address to the initial value
	DMA0->TCD[0].SLAST = -0x0A;		// Source address adjustment
	DMA0->TCD[0].DLAST_SGA = -0x05;	// Destination address adjustment
	
	// Setup control and status register
	DMA0->TCD[0].CSR = 0;
}

