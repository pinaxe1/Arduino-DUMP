/*
 * dma.h
 *
 *  Created on: Oct 14, 2014
 *      Author: b52932
 */

#ifndef DMA_H_
#define DMA_H_

/* Prototypes */
void init_DMA_1Trans(void);
void init_DMA_1Elem(void);

#endif /* DMA_H_ */
