/*	Name: K20D72_DMA
 * 
 *  Author: Freescale Semiconductor Inc.
 *  
 *  Description: Direct Memory Access (DMA) transfer demonstration with the K20D72 development board
 *  using SW1 as the peripheral request trigger. One of two options must be selected in main.h
 *  
 *  	DMA_ONE_TRANSACTION - A single transference of 5 bytes is carried out
 *  	DMA_ONE_ELEMENT     - Five transfers of a single byte each are carried out
 * 
 *
 */

#include "MK20D7.h" /* include peripheral declarations */
#include "dma.h"
#include "main.h"


int main(void)
{
	int i; // Delay variable
	
	// Enable clock and MUX for LEDs
	SIM->SCGC5 |= SIM_SCGC5_PORTC_MASK;
	PORTC->PCR[9] = PORT_PCR_MUX(1);
	PORTC->PCR[10] = PORT_PCR_MUX(1);
	
	// Set LEDs as outputs
	PTC->PDDR |= (1 << 10) | (1 << 9);
	PTC->PCOR |= (1 << 9);  // Turn off Green LED D9
	PTC->PSOR |= (1 << 10); // Turn on Blue LED D10
	
	// Set SW1 as peripheral for DMA request on falling edge
	PORTC->PCR[1] |=PORT_PCR_MUX(0x01) | PORT_PCR_IRQC(0x02)|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK;
	
	// Select size of data transfer
	#if (TEST)
		init_DMA_1Elem();
	#else
		init_DMA_1Trans();
	#endif
		
	while(1)
	{
		// Delay
		for(i = 0; i < 500000; i++)
			__asm("nop");
		
		// Toggle Green LED D9 and Blue LED D10
		PTC->PTOR = (1 << 9) | (1 << 10);
	}
}
