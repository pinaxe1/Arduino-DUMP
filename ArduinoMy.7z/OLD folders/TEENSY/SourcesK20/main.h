/*
 * main.h
 *
 *  Created on: Oct 16, 2014
 *      Author: B52932
 */

#ifndef MAIN_H_
#define MAIN_H_

#define DMA_ONE_TRANSACTION 0 	// 5 bytes per DMA request
#define DMA_ONE_ELEMENT     1	// 1 element per DMA request 

// Select option
#define TEST  DMA_ONE_ELEMENT 	 


#endif /* MAIN_H_ */
