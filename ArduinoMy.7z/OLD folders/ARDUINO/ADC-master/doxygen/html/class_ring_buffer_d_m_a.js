var class_ring_buffer_d_m_a =
[
    [ "RingBufferDMA", "class_ring_buffer_d_m_a.html#a37b578fe20ec7e7a361a614f9e9a2a07", null ],
    [ "~RingBufferDMA", "class_ring_buffer_d_m_a.html#ae7b0ff5b6789ac462a657602dbedc7c4", null ],
    [ "isEmpty", "class_ring_buffer_d_m_a.html#a0c10d34a151d2b9960e2ae58084e5baa", null ],
    [ "isFull", "class_ring_buffer_d_m_a.html#a52f974a38148e4baab0acbd2edb5c0e0", null ],
    [ "read", "class_ring_buffer_d_m_a.html#ac79ee944ee98c4da859c6e5f112022ea", null ],
    [ "start", "class_ring_buffer_d_m_a.html#ac04b74b351c1b37876ad0c954deab5a7", null ],
    [ "void_isr", "class_ring_buffer_d_m_a.html#ad6c8693d4c61182a50a547a3d51aaa28", null ],
    [ "ADC_number", "class_ring_buffer_d_m_a.html#a293d8fa003796812801612f64c1d7aa6", null ],
    [ "b_size", "class_ring_buffer_d_m_a.html#ac1aeb3b7b58d93a74159d8b1def1193c", null ],
    [ "dmaChannel", "class_ring_buffer_d_m_a.html#a289ca5377bb36f35f87127ce9719cbb7", null ],
    [ "p_elems", "class_ring_buffer_d_m_a.html#adf857179fa7ae20d8b439ee5794dc4c2", null ]
];