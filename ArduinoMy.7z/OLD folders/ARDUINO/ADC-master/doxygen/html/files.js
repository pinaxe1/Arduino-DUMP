var files =
[
    [ "ADC.h", "_a_d_c_8h_source.html", null ],
    [ "ADC_Module.h", "_a_d_c___module_8h_source.html", null ],
    [ "RingBuffer.h", "_ring_buffer_8h_source.html", null ],
    [ "RingBufferDMA.h", "_ring_buffer_d_m_a_8h_source.html", null ]
];