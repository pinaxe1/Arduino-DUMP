var searchData=
[
  ['p_5felems',['p_elems',['../class_ring_buffer_d_m_a.html#adf857179fa7ae20d8b439ee5794dc4c2',1,'RingBufferDMA']]]
];
