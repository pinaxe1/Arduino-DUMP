var searchData=
[
  ['adc_5fconfig',['ADC_Config',['../class_a_d_c___module.html#a0092e0915c562b4e318b0aff575315d1',1,'ADC_Module']]],
  ['adc_5fpower_5fspeed_5fconfig',['ADC_Power_Speed_Config',['../class_a_d_c___module.html#a893a14998c08fb929fdfd570ff981ccd',1,'ADC_Module']]]
];
