#include "Arduino.h"
#include "Seg7x8.h"

//----------------------------------------------------------------
//  Инициализация Индикатора и клавиатуры

void Seg7x8init()
{ 
  
  pinMode(dataPin    , OUTPUT); 
  pinMode(clockPin   , OUTPUT);
  pinMode(latchPin   , OUTPUT);

}
//----------------------------------------------------------------
// Метод выводит 10_ичное число на индикатор 8х7
// Ограничен MaxInt 32789
void Digits8Write( int data){ 
  int da;
  if  (data>0) {
  da=data/10000000; reg2Write(1  ,znak[da]);  data=data-10000000*da; // затем cледуюший
  } else {
    data=-data;
    da=data/10000000; reg2Write(1  ,0xBF); data=data-10000000*da; // затем cледуюший
  }
  da=data/1000000; reg2Write(2  ,znak[da]);  data=data-1000000*da; // затем cледуюший
  da=data/100000; reg2Write(4  ,znak[da]);  data=data-100000*da; // затем cледуюший
  da=data/10000; reg2Write(8  ,znak[da]);  data=data-10000*da; // затем cледуюший
  da=data/1000; reg2Write(16 ,znak[da]);  data=data-1000*da; // затем cледуюший
  da=data/100; reg2Write(32 ,znak[da]);  data=data-100*da;  // и так далее
  da=data/10; reg2Write(64 ,znak[da]);  data=data-10*da;   // до самого
  da=data/1; reg2Write(128,znak[da]);                     // младшего разряда
}

//----------------------------------------------------------------
// Метод выводит 2 10_ичных числа на индикатор 8х7
// Ограничен MaxInt 32789
void Digits4x2Write( int data, int data1){ 
  int da;
  if  (data>0) {
  da=data/1000; reg2Write(1  ,znak[da]);  data=data-1000*da; 
  } else {
    data=-data;
    da=data/1000; reg2Write(1  ,0xBF); data=data-1000*da; 
  }
  da=data/100; reg2Write(2  ,znak[da]);  data=data-100*da; 
  da=data/10; reg2Write(4  ,znak[da]);  data=data-10*da; 
  da=data/1; reg2Write(8  ,znak[da]);   
  data=data1; 
  if  (data>0) {
  da=data/1000; reg2Write(16  ,znak[da]);  data=data-1000*da; 
  } else {
    data=-data;
    da=data/1000; reg2Write(16  ,0xBF); data=data-1000*da; 
  }
  da=data/100; reg2Write(32  ,znak[da]);  data=data-100*da; 
  da=data/10; reg2Write(64  ,znak[da]);  data=data-10*da; 
  da=data/1; reg2Write(128  ,znak[da]);   
  reg2Write(0  ,255);
  delay(10); /////////////////////////////////
}

//----------------------------------------------------------------
// выводит произвольный набор бит на 8х7 сегментный индикатор 	 

void Raw8Write( long int data)
{ int i;
  digitalWrite(latchPin, HIGH); //Отключаем вывод на регистре
  for (i=0; i<5 ; i++){ 
    shiftOut(dataPin, clockPin, MSBFIRST, lowByte(data)); 
    data=data>>8; 
  }
  digitalWrite(latchPin, LOW); // "защелкиваем" регистр, чтобы байт появился на его выходах
  digitalWrite(latchPin, HIGH); //Отключаем вывод на регистре
}


//----------------------------------------------------------------
//  записывает один бит в регистр индикаторов

void aBitWrite( byte data) 
{
  digitalWrite(dataPin , data ); // бит в регистр ;
  digitalWrite(clockPin,  LOW ); // проталкиваем 
  digitalWrite(clockPin, HIGH ); // проталкиваем 
}


//----------------------------------------------------------------
//  записывает одно знакоместо в регистр

void regWrite( byte data) 
{
  digitalWrite(latchPin, LOW); //Отключаем вывод на регистре
  shiftOut(dataPin, clockPin, MSBFIRST, data); // проталкиваем 1 байт в регистр индикатора
  digitalWrite(latchPin, HIGH); // "защелкиваем" регистр, чтобы байт появился на его выходах
}

void reg2Write( byte data, byte pose) 
{
  digitalWrite(latchPin, LOW); //Отключаем вывод на регистре
  shiftOut(dataPin, clockPin, MSBFIRST, data); // проталкиваем 1 байт в регистр индикатора
  shiftOut(dataPin, clockPin, MSBFIRST, pose ); // проталкиваем 1 байт в регистр индикатора
  digitalWrite(latchPin, HIGH); // "защелкиваем" регистр, чтобы байт появился на его выходах
}

//----------------------------------------------------------------
//  текст в регистр бегущей (ползущей) строкой
void writeStr( const byte text[])
{ byte count=text[0];
  for(int i=1; i<=count; i++){
    regWrite(text[i]);
    delay(400);
  } 

}
//----------------------------------------------------------------
// Произвольный набор бит в регистр из буфера
void write8S(const byte buf[],byte j)
{ int i;
  digitalWrite(latchPin, HIGH); //Отключаем вывод на регистре
  for (i=j; i<j+5 ; i++) shiftOut(dataPin, clockPin, MSBFIRST, buf[i]); 
  digitalWrite(latchPin, LOW); // "защелкиваем" регистр, чтобы байт появился на его выходах
  digitalWrite(latchPin, HIGH); //Отключаем вывод на регистре

}



