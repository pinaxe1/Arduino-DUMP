#ifndef Seg7x8_h
#define Seg7x8_h

#include "Arduino.h"

//                   0  // pin 0 1  лучше не использовать они 
//                   1  // зарезервированы под прямой сериальный ввод вывод процессора
#define Pin2         2  // 
#define Pin3         3  // 
#define Pin4         4  // 
#define Pin5         5  // 
#define Pin6         6  // 
#define Pin7         7  // 
#define clockPin    8  // SH_CP тактовые импульсы индикатора
#define dataPin      9  // DS данные на индикатор
#define latchPin    10  // ST_CP Защелка индикатора 4х7сег
#define Pin11       11  // 
#define Pin12       12  // 




void write8S(const byte buf[],byte j);// Произвольный набор бит в регистр из буфера
void regWrite( byte data);    // записывает одно знакоместо в регистр <<<<<<<
void reg2Write( byte data, byte pose);
void writeStr(const byte text[]); //  текст в регистр бегущей (ползущей) строкой
void Raw8Write( long int data);  // выводит произвольный набор бит на 4х7 сегментный индикатор 	 
void Digits8Write( int data);   // выводит 10_ичное число на индикатор 4х7
void Digits4x2Write( int data, int data1);   // выводит 10_ичное число на индикатор 4х7
void aBitWrite( byte data);    // записывает один бит в регистр индикаторов
void Seg7x8init();          // инициализация клавиатуры и дисплея

//               positive       negative 
//Знакогенератор PGFEDCBA HEX   PGFEDCBA HEX   
const byte znak[]={
0xC0,   //    0  00111111 0x3F  11000000 0xC0
0xF9,   //    1  00000110 0x06  11111001 0xF9
0xA4,   //    2  01011011 0x5B  10100100 0xA4
0xB0,   //    3  01001111 0x4F  10110000 0xB0
0x99,   //    4  01100110 0x66  10011001 0x99
0x92,   //    5  01101101 0x6D  10010010 0x92
0x82,   //    6  01111101 0x7D  10000010 0x82
0xF8,   //    7  00000111 0x07  11111000 0xF8
0x80,   //    8  01111111 0x7F  10000000 0x80
0x90,   //    9  01101111 0x6F  10010000 0x90
0x88,   //    A  01110111 0x77  10001000 0x88
0x83,   //    b  01111100 0x7C  10000011 0x83
0xC6,   //    C  00111001 0x39  11000110 0xC6
0xA0,   //    d  01011111 0x5E  10100000 0xA0
0x86,   //    E  01111001 0x79  10000110 0x86
0x8E,   //    F  01110001 0x71  10001110 0x8E
0x7b,   //    e  01111011 0x7b 
0x5F,   //    д  01011111 0x5F  д
0x00,   //    _  00000000 0x00 
0x3E,   //    U  00111110 0x3E 
0x1C,   //    u  00011100 0x1C 
0x37,   //    П  00110111 0x37 
0x54,   //    n  01010100 0x54 
0x5C,   //    o  01011100 0x5C   o low
0x63,   //    o  01100011 0x63   o high
0x73,   //    o  01110011 0x73   P
0x40,   //    -  01000000 0x40   just  -
0x08,   //    _  00001000 0x08   lower _
0x01,   //    -  00000001 0x01   upper -
0x41,   //    =  01000001 0x41 
0x76,   //    H  01110110 0x76 
0x74,   //    h  01110100 0x74 
0x30,   //    I  00110000 0x30 
0x38,   //    L  00111000 0x38 
0x18,   //    l  00011000 0x18   L low  
0x36,   //   ||  00110110 0x36 
0x31,   //    Г  00110001 0x31 
0x50,   //    r  01010000 0x50 
0x6E,   //    Y  01101110 0x6E  
0x3D,   //    G  00111101 0x3D 
0x67,   //    q  01100111 0x67 
0x0E,   //    J  00001110 0x0E 
0x0C,   //    j  00001100 0x0C   J low
0x44}; //    7  01000100 0x44   7 low

                  //   9,       П    Р    И    В    Е    Т   
const byte tprivet[]={ 9,0,0,0,0x37,0x73,0x3e,0x7f,0x79,0x07,0,0,0};
                  //   7,       П   Y    C    K
const byte tpusk[]  ={ 7,0,0,0,0x37,0x6e,0x39,0xf2,0,0,0};
                  //   8        П    А    Y    3    A
const byte tpause[] ={ 8,0,0,0,0x37,0x77,0x6e,0x4f,0x77,0,0,0};
                  //  10        П    О    Е    х    А    Л    И
const byte tstart[] ={10,0,0,0,0x37,0x3f,0x79,0xd2,0x77,0x56,0x3e,0,0,0};
                  //  24        В    В    o    д    и        д    и    А    М    M    Е    Т   Р        П    Р    О    В    о    д    А
const byte tdiam[]  ={3,0,0,0,0x3f,0,0,0};
                  //  20        В    В    o    д    и        ч    и    с    л    о        b    и    T    k    о    b     
const byte tvitki[] ={6,0,0,0,0,0x06,0,0,0,0,0 };
                  //   7        О    Б    Е    д
const byte tobed[]  ={ 7,0,0,0,0x3f,0x7d,0x79,0x5f,0,0,0};

#endif


