#include "Arduino.h"
#include "Seg7x4.h"

//----------------------------------------------------------------
//  Инициализация Индикатора и клавиатуры

void Seg7x4init()
{ 
  
  pinMode(dataPin    , OUTPUT); 
  pinMode(clockPin   , OUTPUT);
  pinMode(latchPin   , OUTPUT);

}




//----------------------------------------------------------------
// Метод выводит 10_ичное число на индикатор 4х7

void Digits4Write( int data){ 
  int da;
  digitalWrite(latchPin, HIGH); //Отключаем вывод на регистре
  if  (data>0) {
  da=data/1000; shiftOut(dataPin, clockPin, MSBFIRST, znak[da]); data=data-1000*da; // затем cледуюший
  } else {
    data=-data;
    da=data/1000; shiftOut(dataPin, clockPin, MSBFIRST, 0x40); data=data-1000*da; // затем cледуюший
  }
  da=data/100;  shiftOut(dataPin, clockPin, MSBFIRST, znak[da]); data=data-100*da;  // и так далее
  da=data/10;   shiftOut(dataPin, clockPin, MSBFIRST, znak[da]); data=data-10*da;   // до самого
  da=data/1;    shiftOut(dataPin, clockPin, MSBFIRST, znak[da]);                    // младшего разряда
  digitalWrite(latchPin, LOW); // "защелкиваем" регистр, чтобы байт появился на его выходах
  digitalWrite(latchPin, HIGH); //Отключаем вывод на регистре

}

//----------------------------------------------------------------
// выводит произвольный набор бит на 4х7 сегментный индикатор 	 

void Raw4Write( long int data)
{ int i;
  digitalWrite(latchPin, HIGH); //Отключаем вывод на регистре
  for (i=0; i<5 ; i++){ 
    shiftOut(dataPin, clockPin, MSBFIRST, lowByte(data)); 
    data=data>>8; 
  }
  digitalWrite(latchPin, LOW); // "защелкиваем" регистр, чтобы байт появился на его выходах
  digitalWrite(latchPin, HIGH); //Отключаем вывод на регистре
}


//----------------------------------------------------------------
//  записывает один бит в регистр индикаторов

void aBitWrite( byte data) 
{
  digitalWrite(dataPin , data ); // бит в регистр ;
  digitalWrite(clockPin,  LOW ); // проталкиваем 
  digitalWrite(clockPin, HIGH ); // проталкиваем 
}


//----------------------------------------------------------------
//  записывает одно знакоместо в регистр

void regWrite( byte data, const byte latch) 
{
  digitalWrite(latch, LOW); //Отключаем вывод на регистре
  shiftOut(dataPin, clockPin, MSBFIRST, data); // проталкиваем 1 байт в регистр индикатора
  digitalWrite(latch, HIGH); // "защелкиваем" регистр, чтобы байт появился на его выходах
}

//----------------------------------------------------------------
//  текст в регистр бегущей (ползущей) строкой
void writeStr( const byte text[])
{ byte count=text[0];
  for(int i=1; i<=count; i++){
    regWrite(text[i],latchPin);
    delay(400);
  } 

}
//----------------------------------------------------------------
// Произвольный набор бит в регистр из буфера
void write4S(const byte buf[],byte j)
{ int i;
  digitalWrite(latchPin, HIGH); //Отключаем вывод на регистре
  for (i=j; i<j+5 ; i++) shiftOut(dataPin, clockPin, MSBFIRST, buf[i]); 
  digitalWrite(latchPin, LOW); // "защелкиваем" регистр, чтобы байт появился на его выходах
  digitalWrite(latchPin, HIGH); //Отключаем вывод на регистре

}



